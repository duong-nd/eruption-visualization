<?php
	class Configuration {
		/* const MYSQL_DATABASE = 'wovodat';
		const MYSQL_HOST = 'wovodat.org:3307';
		const MYSQL_USER = 'wovodat_view';
		const MYSQL_PASSWORD = '+00World'; */
		const MYSQL_DATABASE = 'wovodat';
		const MYSQL_HOST = 'localhost:3305';
		const MYSQL_USER = 'wovodatuser';
		const MYSQL_PASSWORD = 'wovodatpassword';
	}
